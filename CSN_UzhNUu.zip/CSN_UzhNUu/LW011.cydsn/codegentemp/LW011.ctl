-- ======================================================================
-- LW011.ctl generated from LW011
-- 03/09/2026 at 13:58
-- This file is auto generated. ANY EDITS YOU MAKE MAY BE LOST WHEN THIS FILE IS REGENERATED!!!
-- ======================================================================

-- PSoC Clock Editor
-- Directives Editor
-- Analog Device Editor
