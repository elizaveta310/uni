# Component constraints for D:\PSoC Creator\CSN_UzhNUu\LW011.cydsn\TopDesign\TopDesign.cysch
# Project: D:\PSoC Creator\CSN_UzhNUu\LW011.cydsn\LW011.cyprj
# Date: Mon, 09 Mar 2026 11:58:46 GMT
